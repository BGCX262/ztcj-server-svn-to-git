/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:46:17
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_user_analyst_room
-- ----------------------------
DROP TABLE IF EXISTS `wm_user_analyst_room`;
CREATE TABLE `wm_user_analyst_room` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `UID` int(10) NOT NULL COMMENT '用户id',
  `ANAID` int(10) NOT NULL COMMENT '分析师id',
  `ADDTIME` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `PASSTIME` datetime NOT NULL COMMENT '过期时间',
  `ADDIP` varchar(50) NOT NULL COMMENT '添加IP',
  `SEVENDAYSEND` bigint(2) NOT NULL DEFAULT '0' COMMENT '0代表未发送7天过期消息，1代表已经发送',
  `EXPIRESSEND` bigint(2) NOT NULL DEFAULT '0' COMMENT '0代表未发送已过期消息，1代表已经发送过期消息',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_user_analyst_room
-- ----------------------------
INSERT INTO `wm_user_analyst_room` VALUES ('1', '8898', '1805', '2014-03-03 17:53:26', '2014-03-06 17:53:30', '127.0.0.1', '0', '0');
INSERT INTO `wm_user_analyst_room` VALUES ('2', '447', '1805', '2014-03-17 16:07:57', '2014-03-18 16:07:51', '127.0.0.1', '0', '0');
