/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:48:07
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_user_roleOrganization
-- ----------------------------
DROP TABLE IF EXISTS `wm_user_roleOrganization`;
CREATE TABLE `wm_user_roleOrganization` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PK(自动增长)',
  `UID` int(11) NOT NULL COMMENT '会员编号',
  `ORGANIZATIONNAME` varchar(50) DEFAULT NULL COMMENT '机构全名',
  `WEB` varchar(100) DEFAULT NULL COMMENT '官方网站',
  `ABBREVIATION` varchar(50) DEFAULT NULL COMMENT '机构简称',
  `CONTACT` varchar(50) DEFAULT NULL COMMENT '联系人',
  `CREATETIME` varchar(50) DEFAULT NULL COMMENT '机构创建时间',
  `TELEPHONE` varchar(50) DEFAULT NULL COMMENT '联系人电话',
  `LICENSENUMBER` varchar(50) DEFAULT NULL COMMENT '营业执照注册号',
  `DUPLICATE` varchar(50) DEFAULT NULL COMMENT '营业执照副本',
  `AUDITSTATE` int(11) NOT NULL DEFAULT '2' COMMENT '审核状态,未通过(0)已通过(1)审核中(2)',
  `PASSTIME` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '通过时间',
  `LASTUPDATETIME` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '最后编辑时间',
  `LASTUPDATEIP` varchar(50) DEFAULT NULL COMMENT '最后编辑IP,默认为当前IP',
  `LASTUPDATEEXPLAIN` varchar(300) DEFAULT NULL COMMENT '最后编辑说明',
  `APPLOGO` varchar(300) DEFAULT NULL COMMENT '交易商LOGO',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UID` (`UID`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8 COMMENT='机构信息表：社区会员机构认证通过后，机构信息\r\n';

-- ----------------------------
-- Records of wm_user_roleOrganization
-- ----------------------------
INSERT INTO `wm_user_roleOrganization` VALUES ('8', '1352', '智通财经网', 'home.wm927.com', '智慧极客', '智通财经网', '2013/02/02', '15977687741', '125632514523652', '2013/11/06/18301383747248.jpg', '1', '2013-11-06 22:13:20', '2013-11-06 22:13:20', '58.64.216.215', null, '2014/01/24/13521390559351.png');
INSERT INTO `wm_user_roleOrganization` VALUES ('15', '1645', '罗马', 'http://home.wm927.com/user/info/edit?uid=1645#personal_data', '智慧极客3333*', '罗马人', '2013/03/08', '13026666796', null, null, '1', '2013-12-31 23:58:45', '2013-12-31 23:58:45', '127.0.0.1', null, '2014/01/03/16451388738350.jpg');
INSERT INTO `wm_user_roleOrganization` VALUES ('16', '8499', '爱地球', 'home.wm927.hk', '爱地球', '撒的付款', '2011/02/02', '12536251425', null, null, '1', '2014-01-03 02:07:11', '2014-01-03 02:07:11', '127.0.0.1', null, '2014/01/03/84991388720238.jpg');
INSERT INTO `wm_user_roleOrganization` VALUES ('17', '9004', '测试机构帐号', null, null, null, null, null, null, null, '2', '2014-02-20 18:11:18', '2014-02-20 18:11:22', '127.0.0.1', null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('18', '740', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:31', '2014-03-03 10:28:31', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('19', '1319', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:31', '2014-03-03 10:28:31', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('20', '1321', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:31', '2014-03-03 10:28:31', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('21', '1322', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:31', '2014-03-03 10:28:31', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('22', '1325', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:31', '2014-03-03 10:28:31', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('23', '1326', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:31', '2014-03-03 10:28:31', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('24', '1327', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:31', '2014-03-03 10:28:31', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('25', '1328', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:31', '2014-03-03 10:28:31', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('26', '1329', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:31', '2014-03-03 10:28:31', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('27', '1334', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:31', '2014-03-03 10:28:31', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('28', '1335', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:31', '2014-03-03 10:28:31', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('29', '1339', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('30', '1340', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('31', '1341', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('32', '1343', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('33', '1348', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('34', '1349', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('35', '1475', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('36', '1476', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('37', '1477', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('38', '1478', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('39', '1479', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('40', '1480', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('41', '1481', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('42', '1582', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('43', '1603', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('44', '1765', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('45', '1766', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('46', '1767', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('47', '1768', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('48', '1833', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('49', '1905', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('50', '1906', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('51', '1908', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('52', '1919', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('53', '1944', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('54', '1945', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:32', '2014-03-03 10:28:32', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('55', '8405', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:33', '2014-03-03 10:28:33', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('56', '8412', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:33', '2014-03-03 10:28:33', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('57', '8420', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:33', '2014-03-03 10:28:33', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('58', '8674', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:33', '2014-03-03 10:28:33', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('59', '8686', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:28:33', '2014-03-03 10:28:33', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('60', '8910', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:29:15', '2014-03-03 10:29:15', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('61', '8976', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:29:15', '2014-03-03 10:29:15', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('62', '8995', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:29:15', '2014-03-03 10:29:15', null, null, null);
INSERT INTO `wm_user_roleOrganization` VALUES ('63', '9063', null, null, null, null, null, null, null, null, '2', '2014-03-03 10:29:15', '2014-03-03 10:29:15', null, null, null);
