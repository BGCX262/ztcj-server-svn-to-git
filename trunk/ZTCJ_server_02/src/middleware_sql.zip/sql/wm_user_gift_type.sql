/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:47:17
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_user_gift_type
-- ----------------------------
DROP TABLE IF EXISTS `wm_user_gift_type`;
CREATE TABLE `wm_user_gift_type` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) DEFAULT NULL COMMENT '礼物名称',
  `TYPE` int(10) NOT NULL DEFAULT '0' COMMENT '0代表要显示的礼物(如鲜花)，1代表不需要显示的礼物(如策略)',
  `PRICE` int(10) NOT NULL DEFAULT '1' COMMENT '价格',
  `SORT` int(10) NOT NULL DEFAULT '1' COMMENT '礼物排序',
  `GIFTIMG` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_user_gift_type
-- ----------------------------
INSERT INTO `wm_user_gift_type` VALUES ('1', '鲜花', '0', '1', '3', 'i_gift_flower.png');
INSERT INTO `wm_user_gift_type` VALUES ('2', '中华烟', '0', '1', '1', 'i_gift_gift.png');
INSERT INTO `wm_user_gift_type` VALUES ('3', '马年吉祥', '0', '1', '2', 'i_gift_gift.png');
