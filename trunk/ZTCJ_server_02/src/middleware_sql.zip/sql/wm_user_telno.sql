/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:48:14
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_user_telno
-- ----------------------------
DROP TABLE IF EXISTS `wm_user_telno`;
CREATE TABLE `wm_user_telno` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PK(自动增长)',
  `UID` int(10) DEFAULT NULL,
  `TELNO` varchar(50) DEFAULT NULL COMMENT '手机号码',
  `CODE` varchar(50) DEFAULT NULL,
  `VALIDCODE` varchar(50) DEFAULT NULL COMMENT '验证码',
  `VALIDSTATE` int(11) DEFAULT NULL COMMENT '验证状态,1(已验证),0(未验证)',
  `VALIDTIME` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '验证时间',
  `VALIDIP` varchar(50) DEFAULT NULL COMMENT '验证IP',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=269 DEFAULT CHARSET=utf8 COMMENT='用户手机验证表，在手机号入库之前，验证手机号';

-- ----------------------------
-- Records of wm_user_telno
-- ----------------------------
INSERT INTO `wm_user_telno` VALUES ('39', null, '13530678634', null, '615436', '0', '2014-03-20 16:19:02', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('40', null, '13026666796', null, '833454', '0', '2014-03-20 13:01:20', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('41', null, '18688947359', null, '640832', '1', '2013-11-06 16:58:30', '183.238.177.138');
INSERT INTO `wm_user_telno` VALUES ('42', null, '15013807342', null, '408523', '1', '2013-11-06 22:07:43', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('43', null, '15032653245', null, '832576', '0', '2013-11-06 22:16:29', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('44', null, '13144842660', null, '815980', '0', '2014-03-02 15:42:28', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('45', null, '13760858108', null, '550198', '1', '2013-11-07 14:07:32', '183.238.177.138');
INSERT INTO `wm_user_telno` VALUES ('46', null, '18676834414', null, '750176', '1', '2013-11-07 17:17:46', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('47', null, '18128855387', null, '964871', '1', '2013-11-08 10:30:14', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('48', null, '13428718273', null, '854391', '1', '2013-11-08 14:59:27', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('49', null, '15957206600', null, '578104', '1', '2013-11-11 12:15:54', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('50', null, '18823380615', null, '712095', '1', '2013-11-11 15:17:50', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('51', null, '18128856866', null, '795312', '1', '2013-11-12 18:15:22', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('52', null, '13144842669', null, '428359', '1', '2013-11-12 22:52:15', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('53', null, '18128856869', null, '927381', '1', '2014-03-04 09:26:59', '183.238.177.138');
INSERT INTO `wm_user_telno` VALUES ('54', null, '18128856858', null, '509521', '0', '2013-11-18 09:36:51', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('55', null, '13794482108', null, '671603', '0', '2013-11-18 09:59:40', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('56', null, '18128856856', null, '214820', '0', '2013-11-18 10:25:17', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('57', null, '13202026758', null, '373218', '0', '2013-11-18 15:23:36', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('58', null, '13824311622', null, '797146', '0', '2013-11-19 15:12:13', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('59', null, '13450293455', null, '947320', '1', '2014-03-05 11:24:23', '183.238.177.138');
INSERT INTO `wm_user_telno` VALUES ('60', null, '15963766675', null, '318645', '0', '2013-11-26 14:14:22', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('61', null, '13713630054', null, '212658', '0', '2013-12-02 15:18:50', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('62', null, '15387145477', null, '128315', '0', '2013-12-05 11:17:45', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('63', null, '13530678639', null, '857360', '0', '2013-12-10 16:48:31', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('64', null, '18126182857', null, '105732', '0', '2013-12-18 10:42:25', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('65', null, '13517618871', null, '237561', '0', '2013-12-26 09:23:27', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('66', null, '15817295324', null, '687265', '0', '2013-12-28 01:23:29', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('67', null, '18682192105', null, '780213', '1', '2013-12-28 02:30:20', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('68', null, '18984152418', null, '769518', '0', '2013-12-28 03:16:11', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('69', null, '13937727925', null, '791057', '0', '2014-01-08 07:00:29', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('70', null, '13523957850', null, '585649', '1', '2014-01-08 22:50:50', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('71', null, '18822881383', null, '718364', '1', '2014-01-16 23:37:52', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('72', null, '18128856854', null, '826807', '1', '2014-01-17 13:33:38', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('73', null, '18817598166', null, '242965', '1', '2014-01-20 17:54:35', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('74', null, '18128855382', null, '947690', '0', '2014-02-11 10:34:34', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('75', '8935', '13026666796', '498467', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('76', '8935', '13026666796', '217635', null, null, '2014-02-18 20:39:22', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('77', '8935', '13026666796', '987496', null, null, '2014-02-18 20:51:15', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('78', '8935', '13026666796', '594813', null, null, '2014-02-18 20:52:09', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('79', '8935', '13026666796', '195386', null, null, '2014-02-18 21:03:50', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('80', '1833', '15018523696', '414530', null, '1', '2014-02-19 10:36:17', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('81', '8939', '18627176779', '283957', null, '1', '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('82', '1918', '15013807342', '597085', null, '1', '2014-02-19 15:20:12', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('83', '1805', '13026666796', '910628', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('84', '8971', '13026666796', '923976', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('85', '1282', '13760858108', '581649', null, '1', '2014-02-19 17:20:37', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('86', '8973', '13026666796', '683015', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('87', '8973', '13026666796', '105613', null, null, '2014-02-19 17:36:44', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('88', '8980', '13758128483', '108379', null, '1', '2014-02-20 18:21:54', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('89', '8980', '13758128483', '501284', null, '1', '2014-02-20 18:25:53', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('90', '9073', '15527856028', '903684', null, '1', '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('91', '9088', '13135681833', '714329', null, '1', '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('92', '925', '13612864817', '130924', null, '1', '2014-02-28 21:27:05', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('93', '925', '13612864817', '773018', null, '1', '2014-02-28 21:28:06', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('94', '9188', '18718577933', '736247', null, '1', '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('95', '9188', '18718577933', '356238', null, '1', '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('96', '9198', '13026666796', '535910', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('97', '9199', '13026666796', '161827', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('98', '9199', '13026666796', '850128', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('99', '9199', '13026666796', '474609', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('100', '9200', '15013550480', '962391', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('101', '9200', '13026666796', '983746', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('102', '1645', '13026666796', '472631', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('103', '925', '13612864817', '203569', null, '1', '2014-03-02 21:42:19', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('104', '9214', '15268114776', '608915', null, '1', '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('105', '9214', '15268114776', '653617', null, '1', '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('106', '9217', '15268114776', '632590', null, '1', '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('107', '9234', '18128556877', '483926', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('108', '9234', '18128856877', '317463', null, '1', '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('109', '9234', '18128856877', '971436', null, '1', '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('110', null, '13751044469', null, '645484', '0', '2014-03-03 15:18:14', '113.89.43.99');
INSERT INTO `wm_user_telno` VALUES ('111', null, '13049825117', null, '445135', '1', '2014-03-31 15:43:45', '125.88.27.2');
INSERT INTO `wm_user_telno` VALUES ('112', null, '15878394753', null, '241967', '0', '2014-03-11 14:26:28', '123.151.28.33');
INSERT INTO `wm_user_telno` VALUES ('113', '1930', '15016711500', '641263', '878816', '1', '2014-03-25 17:50:33', '125.88.27.2');
INSERT INTO `wm_user_telno` VALUES ('114', '9267', '18128856853', '804687', null, '1', '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('115', '8369', '18682390725', '287215', null, '1', '2014-03-14 14:59:51', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('116', null, '13343148588', null, '809347', '0', '2014-03-03 23:03:01', '106.118.230.127');
INSERT INTO `wm_user_telno` VALUES ('117', null, '18575586411', null, '856852', '1', '2014-03-05 14:41:09', '183.238.177.138');
INSERT INTO `wm_user_telno` VALUES ('118', null, '18680662718', null, '205331', '1', '2014-03-05 15:50:40', '112.90.78.25');
INSERT INTO `wm_user_telno` VALUES ('119', null, '13027968839', null, '083441', '1', '2014-03-06 09:39:45', '14.17.18.146');
INSERT INTO `wm_user_telno` VALUES ('120', '1645', '13026666796', '390461', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('121', null, '18320799700', null, '882254', '1', '2014-03-05 14:07:34', '127.0.0.1');
INSERT INTO `wm_user_telno` VALUES ('126', '9333', '15674809354', '224670', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('122', '9332', '15674803554', '903412', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('123', '9332', '15674809354', '920631', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('124', '9332', '15674809354', '336472', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('125', '9332', '15674809354', '173160', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('127', '1645', '13026666796', '239674', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('128', '9334', '15674845458', '730912', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('129', '1645', '13026666796', '931792', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('130', '1645', '13026666796', '185624', null, null, '0000-00-00 00:00:00', '183.61.160.216');
INSERT INTO `wm_user_telno` VALUES ('131', '1645', '13026666796', '872681', null, null, '0000-00-00 00:00:00', '119.147.146.189');
INSERT INTO `wm_user_telno` VALUES ('132', '1645', '13027968839', '358791', null, '1', '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('133', '1645', '13026666796', '150326', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('134', '1645', '13026666796', '187419', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('135', '1645', '13027968839', '787431', null, '1', '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('136', '9336', '18682192105', '705769', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('137', '9336', '18682192105', '268950', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('138', '1645', '13027968839', '419802', null, '1', '0000-00-00 00:00:00', '180.153.114.199');
INSERT INTO `wm_user_telno` VALUES ('139', '9338', '18664276772', '230184', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('140', '9338', '18664276771', '321583', null, '1', '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('141', '1025', '15957206600', '308569', null, '1', '2014-03-06 09:48:50', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('142', '1025', '15957206600', '585609', null, '1', '2014-03-06 09:50:06', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('143', '9348', '15013807342', '242315', null, '1', '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('144', null, '13774359098', null, '536210', '0', '2014-03-06 16:45:22', '116.231.205.244');
INSERT INTO `wm_user_telno` VALUES ('145', null, '15846334536', null, '886749', '0', '2014-03-12 10:12:58', '125.88.27.2');
INSERT INTO `wm_user_telno` VALUES ('146', null, '13612119698', null, '993230', '0', '2014-03-07 10:01:46', '211.103.89.95');
INSERT INTO `wm_user_telno` VALUES ('147', null, '13820873419', null, '645927', '1', '2014-03-07 10:02:42', '211.103.89.95');
INSERT INTO `wm_user_telno` VALUES ('148', null, '13906771055', null, '395710', '0', '2014-03-07 15:08:11', '125.109.161.186');
INSERT INTO `wm_user_telno` VALUES ('149', '9382', '15674809354', '419273', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('150', '9382', '15674809354', '462538', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('151', '9385', '18682192105', '154726', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('152', '9385', '18682192105', '730869', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('153', null, '18617006068', null, '955736', '1', '2014-03-07 17:36:58', '125.88.27.2');
INSERT INTO `wm_user_telno` VALUES ('154', '9385', '18682192105', '602856', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('155', '9385', '18682192105', '569317', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('156', '9386', '18682192105', '609856', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('157', '9386', '18682192105', '436287', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('158', '9386', '18682192105', '532514', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('159', '9386', '18682192105', '836275', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('160', '9386', '18682192105', '331697', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('161', '9386', '18682192105', '403824', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('162', '9386', '18682192105', '189750', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('163', '9386', '18682192105', '174396', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('164', '9386', '18682192105', '165813', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('165', '9386', '18682192105', '309213', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('166', null, '18771570108', null, '990174', '1', '2014-03-07 17:48:45', '127.0.0.1');
INSERT INTO `wm_user_telno` VALUES ('167', '9386', '18682192105', '257698', null, null, '0000-00-00 00:00:00', '183.62.152.90');
INSERT INTO `wm_user_telno` VALUES ('168', '9391', '18682192105', '964107', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('169', '9392', '18682192105', '679052', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('170', '9392', '18682192105', '142769', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('172', '9392', '18682192105', '126857', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('171', '9392', '18682192105', '353914', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('173', '9391', '18682192105', '556189', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('174', '9393', '18682192105', '457418', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('175', '9393', '18682192105', '943607', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('176', '1897', '18682192105', '608175', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('242', '1645', '13026666796', '459268', null, null, '2014-03-20 16:47:26', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('247', null, '18128856871', null, '353234', '1', '2014-03-21 16:29:36', '123.151.28.33');
INSERT INTO `wm_user_telno` VALUES ('177', '9415', '18682192105', '325178', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('178', '1897', '18682192105', '625361', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('179', '1897', '18682192105', '376098', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('180', '9417', '15674809354', '196087', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('181', '9417', '15674809354', '576091', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('182', '9421', '13517267215', '243875', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('183', '9430', '18682192105', '668457', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('184', '9430', '18682192105', '521679', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('185', null, '18907076000', null, '157309', '0', '2014-03-11 10:59:24', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('186', null, '13266627479', null, '349637', '1', '2014-03-11 14:32:35', '125.88.27.2');
INSERT INTO `wm_user_telno` VALUES ('188', null, '18128855391', null, '489265', '1', '2014-03-12 10:25:46', '125.88.27.2');
INSERT INTO `wm_user_telno` VALUES ('187', null, '15989890831', null, '255495', '1', '2014-03-11 17:23:00', '219.150.71.145');
INSERT INTO `wm_user_telno` VALUES ('189', '408', '13590293386', '583064', null, null, '2014-03-12 11:58:52', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('190', '9459', '18682192105', '496418', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('191', '9459', '18682192105', '205238', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('192', '9459', '18682192105', '445723', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('193', '9459', '18682192105', '449205', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('194', '9459', '18582192105', '638497', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('195', '9459', '18582192105', '250639', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('196', null, '18682390725', null, '129763', '0', '2014-03-12 15:24:09', '125.88.27.2');
INSERT INTO `wm_user_telno` VALUES ('197', null, '18682390725', null, '633854', '0', '2014-03-12 15:26:09', '125.88.27.2');
INSERT INTO `wm_user_telno` VALUES ('198', null, '18682390725', null, '784182', '0', '2014-03-12 15:28:01', '125.88.27.2');
INSERT INTO `wm_user_telno` VALUES ('199', null, '18682390725', null, '824405', '0', '2014-03-12 15:29:39', '125.88.27.2');
INSERT INTO `wm_user_telno` VALUES ('200', null, '13692169417', null, '095223', '0', '2014-03-31 13:49:35', '183.238.227.114');
INSERT INTO `wm_user_telno` VALUES ('201', null, '18682390725', null, '468448', '0', '2014-03-12 15:32:02', '125.88.27.2');
INSERT INTO `wm_user_telno` VALUES ('202', '1897', '18582192105', '589065', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('203', null, '18682390725', null, '387429', '0', '2014-03-12 16:19:39', '125.88.27.2');
INSERT INTO `wm_user_telno` VALUES ('204', '9469', '18681092105', '157018', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('205', '9469', '18681092105', '502597', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('206', '1645', '13026666796', '725913', null, null, '2014-03-13 10:40:51', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('207', '1645', '13026666796', '385247', null, null, '2014-03-13 10:42:12', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('208', '1645', '13026666796', '598674', null, null, '0000-00-00 00:00:00', '14.17.29.85');
INSERT INTO `wm_user_telno` VALUES ('209', '1385', '13450293455', '143052', null, null, '2014-03-13 10:57:43', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('210', '1293', '18128856869', '147510', null, null, '2014-03-13 11:01:03', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('211', '1645', '13027968839', '376924', null, null, '0000-00-00 00:00:00', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('212', '1645', '13026666796', '497341', null, null, '0000-00-00 00:00:00', '112.90.78.25');
INSERT INTO `wm_user_telno` VALUES ('213', null, '18682390725', null, '435347', '0', '2014-03-14 14:46:57', '219.150.71.145');
INSERT INTO `wm_user_telno` VALUES ('214', null, '18682390725', null, '870837', '0', '2014-03-14 14:55:17', '123.151.28.33');
INSERT INTO `wm_user_telno` VALUES ('215', null, '18682390725', null, '998014', '0', '2014-03-14 14:56:48', '127.0.0.1');
INSERT INTO `wm_user_telno` VALUES ('216', null, '18682390725', null, '914184', '0', '2014-03-14 14:58:02', '127.0.0.1');
INSERT INTO `wm_user_telno` VALUES ('217', null, '18682390725', null, '422466', '0', '2014-03-14 14:59:18', '127.0.0.1');
INSERT INTO `wm_user_telno` VALUES ('218', null, '18682390725', null, '939207', '0', '2014-03-14 14:59:42', '127.0.0.1');
INSERT INTO `wm_user_telno` VALUES ('219', '1645', '13026666796', '303685', null, null, '0000-00-00 00:00:00', '14.17.18.152');
INSERT INTO `wm_user_telno` VALUES ('220', '9495', '15674809354', '139046', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('221', '1645', '13026666796', '419762', null, null, '0000-00-00 00:00:00', '14.17.18.143');
INSERT INTO `wm_user_telno` VALUES ('222', null, '13385111490', null, '782319', '1', '2014-03-15 08:53:37', '111.121.33.62');
INSERT INTO `wm_user_telno` VALUES ('223', null, '15986795951', null, '336640', '0', '2014-03-15 10:39:53', '211.142.225.216');
INSERT INTO `wm_user_telno` VALUES ('224', '1645', '13026666796', '390754', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('225', '1645', '13026666796', '454932', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('226', '9525', '13026666796', '445386', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('227', '1805', '13530678634', '436172', null, null, '0000-00-00 00:00:00', '58.64.216.215');
INSERT INTO `wm_user_telno` VALUES ('228', '9528', '15674809354', '256724', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('229', '1385', '13450293455', '869245', null, null, '2014-03-17 19:38:29', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('230', '1293', '18128856869', '838052', null, null, '2014-03-17 19:39:05', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('231', null, '15172731777', null, '633157', '0', '2014-03-17 21:48:19', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('232', null, '18665906985', null, '812927', '1', '2014-03-18 12:07:01', '27.24.141.44');
INSERT INTO `wm_user_telno` VALUES ('233', null, '13510407746', null, '106148', '1', '2014-03-18 12:08:59', '27.24.141.44');
INSERT INTO `wm_user_telno` VALUES ('234', '1645', '13026666796', '465947', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('235', null, '15625179780', null, '387957', '0', '2014-03-19 14:36:29', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('236', '9376', '15625179780', '617058', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('237', '9376', '15625179780', '734687', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('238', '1645', '13026666796', '248926', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('239', '1645', '13026666796', '847980', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('240', '1805', '13686824396', '914756', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('241', '1930', '15016711500', '549203', null, null, '2014-03-20 14:28:17', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('243', '1805', '13530678634', '938265', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('244', '1639', '18682192105', '812736', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('245', '1270', '18676834414', '751247', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('246', null, '18628210363', null, '401360', '1', '2014-03-21 02:00:13', '14.29.127.211');
INSERT INTO `wm_user_telno` VALUES ('248', '9561', '13026666796', '335126', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('249', null, '18128826871', null, '504261', '0', '2014-03-21 11:17:05', '219.150.71.145');
INSERT INTO `wm_user_telno` VALUES ('250', '9586', '15071075089', '706842', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('251', null, '18622679528', null, '837160', '1', '2014-03-25 15:09:02', '202.99.113.41');
INSERT INTO `wm_user_telno` VALUES ('252', null, '13718292595', null, '711811', '0', '2014-03-25 17:23:33', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('253', '9613', '13121177590', '771942', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('254', '9613', '13121177590', '359763', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('255', '9613', '13717941524', '503487', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('256', '9646', '13097075905', '904853', null, null, '0000-00-00 00:00:00', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('257', null, '15527153109', null, '674886', '0', '2014-03-28 09:42:17', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('258', '9661', '13802748162', '116529', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('259', '9661', '13802748162', '450968', null, null, '2014-03-28 15:18:38', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('260', '9614', '15016711500', '494351', null, null, '2014-03-31 14:28:28', '192.168.0.12');
INSERT INTO `wm_user_telno` VALUES ('261', '1645', '13026666796', '460182', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('262', null, '18554672038', null, '460576', '0', '2014-04-01 14:54:29', '183.238.177.138');
INSERT INTO `wm_user_telno` VALUES ('263', '1645', '13026666796', '861840', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('264', '1645', '13026666796', '546890', null, null, '0000-00-00 00:00:00', '192.168.0.2');
INSERT INTO `wm_user_telno` VALUES ('265', null, '18793427505', null, '308899', '0', '2014-04-01 22:39:41', '14.29.127.191');
INSERT INTO `wm_user_telno` VALUES ('266', '9696', '18127753305', '808436', null, null, '0000-00-00 00:00:00', '192.168.0.70');
INSERT INTO `wm_user_telno` VALUES ('267', '9696', '18127753305', '424057', null, null, '0000-00-00 00:00:00', '192.168.0.70');
INSERT INTO `wm_user_telno` VALUES ('268', '9696', '18127753305', '665731', null, null, '0000-00-00 00:00:00', '192.168.0.70');
