/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:47:07
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_user_gift
-- ----------------------------
DROP TABLE IF EXISTS `wm_user_gift`;
CREATE TABLE `wm_user_gift` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(20) NOT NULL COMMENT '礼物名称',
  `TYPE` int(10) NOT NULL DEFAULT '0' COMMENT '礼物类型',
  `GIFTIMG` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_user_gift
-- ----------------------------
INSERT INTO `wm_user_gift` VALUES ('1', '好评', '0', 'i_gift_good.png');
INSERT INTO `wm_user_gift` VALUES ('2', '礼物', '0', 'i_gift_strategy.png');
INSERT INTO `wm_user_gift` VALUES ('3', '秘笈', '0', 'i_gift_cheats.png');
INSERT INTO `wm_user_gift` VALUES ('4', '策略', '0', 'i_gift_strategy.png');
INSERT INTO `wm_user_gift` VALUES ('5', '策略服务', '0', 'i_gift_strategy_service.png');
