/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:41:54
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_blog_articleClass
-- ----------------------------
DROP TABLE IF EXISTS `wm_blog_articleClass`;
CREATE TABLE `wm_blog_articleClass` (
  `ID` int(10) NOT NULL AUTO_INCREMENT COMMENT 'PK(自动增长)',
  `BLOGCLASSNAME` varchar(300) NOT NULL COMMENT '类型名称',
  `PARENTID` int(10) DEFAULT NULL COMMENT '分类父ID',
  `CLASSLEVEL` int(10) DEFAULT NULL COMMENT '分类级别：0代表对所有人公开，1代表对自己关注的人观看',
  `CLASSSORT` int(10) DEFAULT NULL COMMENT '分类排序值',
  `ADDADMINID` int(10) DEFAULT NULL COMMENT '添加管理员',
  `ADMINREMARK` varchar(500) DEFAULT NULL COMMENT '管理员备注',
  `ADDTIME` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `ADDIP` varchar(50) NOT NULL COMMENT '添加IP',
  `LASTUPDATETIME` datetime NOT NULL COMMENT '最后编辑时间',
  `LASTUPDATEIP` varchar(50) NOT NULL COMMENT '最后编辑IP',
  `LASTUPDATEADMINID` int(11) DEFAULT NULL COMMENT '最后编辑管理员,关联管理员ID',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='博客分类表';

-- ----------------------------
-- Records of wm_blog_articleClass
-- ----------------------------
INSERT INTO `wm_blog_articleClass` VALUES ('1', '黄金', '0', '0', '1', '1', '1', '2013-09-25 16:01:35', '127.0.0.1', '2013-09-25 16:01:26', '127.0.0.1', '1');
INSERT INTO `wm_blog_articleClass` VALUES ('2', '白银', '0', '0', '2', '1', '1', '2013-09-25 16:01:51', '127.0.0.1', '2013-09-25 16:01:44', '127.0.0.1', '1');
INSERT INTO `wm_blog_articleClass` VALUES ('3', '外汇', '0', '0', '3', '1', '1', '2013-09-25 16:02:03', '127.0.0.1', '2013-09-25 16:01:56', '127.0.0.1', '1');
INSERT INTO `wm_blog_articleClass` VALUES ('4', '其它', '0', '0', '98', '1', '1', '2013-09-25 16:02:18', '127.0.0.1', '2013-09-25 16:02:10', '127.0.0.1', '1');
INSERT INTO `wm_blog_articleClass` VALUES ('5', '草稿箱', '0', '1', '99', '1', '1', '2013-11-08 14:59:29', '127.0.0.1', '2013-11-08 14:59:31', '127.0.0.1', '1');
INSERT INTO `wm_blog_articleClass` VALUES ('6', 'APP信息', '0', '1', '6', '1', '1', '2013-11-20 22:35:37', '127.0.0.1', '2013-11-20 22:35:40', '127.0.0.1', '1');
INSERT INTO `wm_blog_articleClass` VALUES ('7', '开户指南', '0', '1', '7', '1', '1', '2013-11-20 22:36:00', '127.0.0.1', '2013-11-20 22:36:03', '127.0.0.1', '1');
INSERT INTO `wm_blog_articleClass` VALUES ('9', '天通银', '0', '0', '4', '1', '1', '2013-12-02 19:57:29', '127.0.0.1', '2013-12-02 19:57:35', '127.0.0.1', '1');
INSERT INTO `wm_blog_articleClass` VALUES ('10', '粤贵银', '0', '0', '5', '1', '1', '2013-12-02 19:58:06', '127.0.0.1', '2013-12-02 19:58:12', '127.0.0.1', '1');
