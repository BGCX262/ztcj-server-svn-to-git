/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:45:54
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_sys_advice_number
-- ----------------------------
DROP TABLE IF EXISTS `wm_sys_advice_number`;
CREATE TABLE `wm_sys_advice_number` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `ADVICENUMBER` int(10) NOT NULL DEFAULT '0' COMMENT '系统的通知数目',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_sys_advice_number
-- ----------------------------
INSERT INTO `wm_sys_advice_number` VALUES ('1', '1');
