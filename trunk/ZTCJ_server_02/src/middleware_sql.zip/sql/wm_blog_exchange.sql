/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:42:37
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_blog_exchange
-- ----------------------------
DROP TABLE IF EXISTS `wm_blog_exchange`;
CREATE TABLE `wm_blog_exchange` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `ANAID` int(10) NOT NULL COMMENT '分析师房间IP',
  `UID` int(10) NOT NULL,
  `TYPE` int(10) NOT NULL COMMENT '0代表向分析师提问，1代表向网友提问，2代表分析师回答',
  `COMID` int(10) DEFAULT NULL COMMENT '提问id',
  `CONTENT` varchar(2000) DEFAULT NULL COMMENT '交流内容',
  `ADDTIME` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ADDIP` varchar(50) NOT NULL,
  `ISANSWER` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0代表未回答，1代表已回答',
  `ISDELETE` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0代表未删除，1代表已删除',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_blog_exchange
-- ----------------------------
