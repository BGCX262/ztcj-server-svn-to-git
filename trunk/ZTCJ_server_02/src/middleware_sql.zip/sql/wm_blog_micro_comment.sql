/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:43:03
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_blog_micro_comment
-- ----------------------------
DROP TABLE IF EXISTS `wm_blog_micro_comment`;
CREATE TABLE `wm_blog_micro_comment` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USERID` int(11) NOT NULL DEFAULT '1805' COMMENT '评论人ID',
  `UID` int(11) NOT NULL DEFAULT '1805' COMMENT '被评论人的id',
  `COMMENTBLOGID` int(11) NOT NULL COMMENT '评论博客ID',
  `COMMENTCONTENT` varchar(10000) NOT NULL COMMENT '评论内容',
  `COMMENTDATE` datetime NOT NULL COMMENT '评论时间',
  `COMMENBLOGID` int(11) DEFAULT NULL COMMENT '回复评论ID:关联评论id',
  `ISDELETE` int(11) DEFAULT NULL COMMENT '是否删除:未删除(0) 删除(1)',
  `COMMENTLEVEL` int(3) NOT NULL DEFAULT '1' COMMENT '评论级数(1代表一级评论，2代表二级评论)',
  `TERMINAL` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `UID` (`UID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2413 DEFAULT CHARSET=utf8 COMMENT='博客评论表';

-- ----------------------------
-- Records of wm_blog_micro_comment
-- ----------------------------
