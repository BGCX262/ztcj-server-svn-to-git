/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:43:42
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_blog_purview
-- ----------------------------
DROP TABLE IF EXISTS `wm_blog_purview`;
CREATE TABLE `wm_blog_purview` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PK(自动增长)',
  `BLOGNAME` varchar(50) NOT NULL COMMENT '权限名称',
  `ADDADMINID` int(10) DEFAULT NULL COMMENT '添加管理员,关联管理员ID',
  `ADMINREMARK` varchar(500) DEFAULT NULL COMMENT '管理员备注',
  `ADDTIME` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ADDIP` varchar(50) NOT NULL COMMENT '添加IP',
  `LASTUPDATETIME` datetime NOT NULL COMMENT '最后编辑时间',
  `LASTUPDATEIP` varchar(50) NOT NULL COMMENT '最后编辑IP',
  `LASTUPDATEADMINID` int(10) DEFAULT NULL COMMENT '最后编辑管理员',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='博客权限表';

-- ----------------------------
-- Records of wm_blog_purview
-- ----------------------------
