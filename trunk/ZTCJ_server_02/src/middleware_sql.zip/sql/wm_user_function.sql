/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:46:59
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_user_function
-- ----------------------------
DROP TABLE IF EXISTS `wm_user_function`;
CREATE TABLE `wm_user_function` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) NOT NULL COMMENT '功能名称',
  `MARK` varchar(200) DEFAULT NULL COMMENT '功能作用',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_user_function
-- ----------------------------
INSERT INTO `wm_user_function` VALUES ('1', '喊单', '分析师或机构喊单功能');
INSERT INTO `wm_user_function` VALUES ('2', '申请分析师认证或者机构认证', '普通用户才可以申请认证功能');
INSERT INTO `wm_user_function` VALUES ('3', '分析师账号', '只有分析师才有VIP标识');
INSERT INTO `wm_user_function` VALUES ('4', '机构账号', '只有机构才有的标识');
INSERT INTO `wm_user_function` VALUES ('5', 'APP在线答疑与实战圈子', '只有APP分析师才享有的权限');
INSERT INTO `wm_user_function` VALUES ('6', '分析师绑定机构管理', '只有APP分析师才享有的绑定机构权限');
INSERT INTO `wm_user_function` VALUES ('7', '机构绑定分析师', '只有机构才享有的绑定分析师权限');
INSERT INTO `wm_user_function` VALUES ('8', 'APP分析师管理', '只有APP分析师才享有的管理');
INSERT INTO `wm_user_function` VALUES ('9', 'APP机构管理', '只有APP机构才享有的权限管理');
