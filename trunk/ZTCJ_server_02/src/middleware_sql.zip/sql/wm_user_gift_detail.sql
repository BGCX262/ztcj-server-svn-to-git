/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:47:12
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_user_gift_detail
-- ----------------------------
DROP TABLE IF EXISTS `wm_user_gift_detail`;
CREATE TABLE `wm_user_gift_detail` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `UID` int(10) NOT NULL COMMENT '用户ID',
  `GIFTID` int(10) DEFAULT NULL COMMENT '礼物ID(如策略，秘笈等需要查看详情的)',
  `TYPE` tinyint(4) NOT NULL DEFAULT '1' COMMENT '赠送的类型，关联wm_user_gift表对应的ID',
  `SENDID` int(10) NOT NULL COMMENT '赠送者ID',
  `GIFTNAME` varchar(500) DEFAULT NULL COMMENT '赠送的类型，关联wm_user_gift表对应的ID',
  `NUMBER` int(10) NOT NULL DEFAULT '1' COMMENT '赠送的数量',
  `PRICE` int(10) NOT NULL DEFAULT '1' COMMENT '赠送的价格',
  `MONEY` int(10) NOT NULL DEFAULT '0' COMMENT '赚取的金币(礼物数量*金币价格)',
  `ADDTIME` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '赠送时间',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_user_gift_detail
-- ----------------------------
