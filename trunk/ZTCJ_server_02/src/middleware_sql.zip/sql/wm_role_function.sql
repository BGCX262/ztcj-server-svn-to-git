/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:44:38
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_role_function
-- ----------------------------
DROP TABLE IF EXISTS `wm_role_function`;
CREATE TABLE `wm_role_function` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `ROLEID` varchar(50) NOT NULL COMMENT '功能模块名称',
  `FUNCTIONID` int(10) NOT NULL COMMENT '功能模块ID',
  `ISOPEN` tinyint(4) NOT NULL COMMENT '代表当前功能显示还是隐藏(0隐藏，1显示)',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_role_function
-- ----------------------------
INSERT INTO `wm_role_function` VALUES ('1', '1', '1', '1');
INSERT INTO `wm_role_function` VALUES ('2', '1', '2', '2');
INSERT INTO `wm_role_function` VALUES ('3', '1', '3', '1');
INSERT INTO `wm_role_function` VALUES ('4', '1', '4', '0');
INSERT INTO `wm_role_function` VALUES ('5', '1', '5', '1');
INSERT INTO `wm_role_function` VALUES ('6', '1', '6', '1');
INSERT INTO `wm_role_function` VALUES ('7', '1', '7', '0');
INSERT INTO `wm_role_function` VALUES ('8', '1', '8', '1');
INSERT INTO `wm_role_function` VALUES ('9', '2', '1', '0');
INSERT INTO `wm_role_function` VALUES ('10', '2', '2', '1');
INSERT INTO `wm_role_function` VALUES ('11', '2', '3', '0');
INSERT INTO `wm_role_function` VALUES ('12', '2', '4', '0');
INSERT INTO `wm_role_function` VALUES ('13', '2', '5', '0');
INSERT INTO `wm_role_function` VALUES ('14', '2', '6', '0');
INSERT INTO `wm_role_function` VALUES ('15', '2', '7', '0');
INSERT INTO `wm_role_function` VALUES ('16', '2', '8', '0');
INSERT INTO `wm_role_function` VALUES ('17', '3', '1', '1');
INSERT INTO `wm_role_function` VALUES ('18', '3', '2', '0');
INSERT INTO `wm_role_function` VALUES ('19', '3', '3', '1');
INSERT INTO `wm_role_function` VALUES ('20', '3', '4', '0');
INSERT INTO `wm_role_function` VALUES ('21', '3', '5', '0');
INSERT INTO `wm_role_function` VALUES ('22', '3', '6', '0');
INSERT INTO `wm_role_function` VALUES ('23', '3', '7', '0');
INSERT INTO `wm_role_function` VALUES ('24', '3', '8', '1');
INSERT INTO `wm_role_function` VALUES ('25', '4', '1', '1');
INSERT INTO `wm_role_function` VALUES ('26', '4', '2', '0');
INSERT INTO `wm_role_function` VALUES ('27', '4', '3', '0');
INSERT INTO `wm_role_function` VALUES ('28', '4', '4', '1');
INSERT INTO `wm_role_function` VALUES ('29', '4', '5', '0');
INSERT INTO `wm_role_function` VALUES ('30', '4', '6', '0');
INSERT INTO `wm_role_function` VALUES ('31', '4', '7', '1');
INSERT INTO `wm_role_function` VALUES ('32', '4', '8', '0');
INSERT INTO `wm_role_function` VALUES ('33', '5', '1', '1');
INSERT INTO `wm_role_function` VALUES ('34', '5', '2', '0');
INSERT INTO `wm_role_function` VALUES ('35', '5', '3', '1');
INSERT INTO `wm_role_function` VALUES ('36', '5', '4', '0');
INSERT INTO `wm_role_function` VALUES ('37', '5', '5', '1');
INSERT INTO `wm_role_function` VALUES ('38', '5', '6', '1');
INSERT INTO `wm_role_function` VALUES ('39', '5', '7', '0');
INSERT INTO `wm_role_function` VALUES ('40', '5', '8', '1');
INSERT INTO `wm_role_function` VALUES ('41', '6', '1', '1');
INSERT INTO `wm_role_function` VALUES ('42', '6', '2', '0');
INSERT INTO `wm_role_function` VALUES ('43', '6', '3', '0');
INSERT INTO `wm_role_function` VALUES ('44', '6', '4', '1');
INSERT INTO `wm_role_function` VALUES ('45', '6', '5', '0');
INSERT INTO `wm_role_function` VALUES ('46', '6', '6', '0');
INSERT INTO `wm_role_function` VALUES ('47', '6', '7', '1');
INSERT INTO `wm_role_function` VALUES ('48', '6', '8', '0');
INSERT INTO `wm_role_function` VALUES ('49', '1', '9', '0');
INSERT INTO `wm_role_function` VALUES ('50', '2', '9', '0');
INSERT INTO `wm_role_function` VALUES ('51', '3', '9', '0');
INSERT INTO `wm_role_function` VALUES ('52', '4', '9', '0');
INSERT INTO `wm_role_function` VALUES ('53', '5', '9', '0');
INSERT INTO `wm_role_function` VALUES ('54', '6', '9', '1');
