/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:47:57
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_user_role
-- ----------------------------
DROP TABLE IF EXISTS `wm_user_role`;
CREATE TABLE `wm_user_role` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(20) NOT NULL COMMENT '角色名字',
  `PARENTID` int(10) NOT NULL COMMENT '角色父id',
  `MARK` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_user_role
-- ----------------------------
INSERT INTO `wm_user_role` VALUES ('1', '超级管理员', '0', '所有角色的最高管理员，拥有所有权限');
INSERT INTO `wm_user_role` VALUES ('2', '普通用户', '1', '执行普通用户角色');
INSERT INTO `wm_user_role` VALUES ('3', '分析师', '1', '执行分析师权限，用户除了普通权限以外，还有喊单功能权限');
INSERT INTO `wm_user_role` VALUES ('4', '机构', '1', '执行机构权限，除了普通用户权限，还有喊单权限');
INSERT INTO `wm_user_role` VALUES ('5', 'APP分析师', '3', '除了拥有分析师权限外，还拥有APP特殊权限');
INSERT INTO `wm_user_role` VALUES ('6', 'APP机构', '4', '除了拥有机构权限，还拥有APP机构权限');
