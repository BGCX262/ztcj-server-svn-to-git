/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:47:42
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_user_money
-- ----------------------------
DROP TABLE IF EXISTS `wm_user_money`;
CREATE TABLE `wm_user_money` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `UID` int(10) NOT NULL,
  `LAVE` int(10) NOT NULL DEFAULT '0' COMMENT '结余',
  `TYPE` int(10) NOT NULL DEFAULT '0' COMMENT '交易类型(0存入，1支出)',
  `MONEY` int(10) NOT NULL DEFAULT '0' COMMENT '金额',
  `GIFTID` int(10) DEFAULT NULL COMMENT '礼物ID',
  `GIFTTYPE` tinyint(4) NOT NULL DEFAULT '0' COMMENT '关联礼物表wm_user_gift,0代表不是礼物内容，不需要拿更多内容',
  `DETAIL` varchar(500) DEFAULT NULL COMMENT '交易明细',
  `ADDTIME` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '时间',
  `INTEGRAL` int(10) NOT NULL DEFAULT '0' COMMENT '赠送积分',
  PRIMARY KEY (`ID`),
  KEY `UID` (`UID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_user_money
-- ----------------------------
INSERT INTO `wm_user_money` VALUES ('23', '1805', '45', '0', '1', null, '1', '购买金币', '2014-01-09 01:26:39', '0');
INSERT INTO `wm_user_money` VALUES ('24', '1805', '46', '0', '1', null, '1', '购买金币', '2014-01-09 01:35:18', '0');
INSERT INTO `wm_user_money` VALUES ('25', '1805', '47', '0', '1', null, '1', '购买金币', '2014-01-09 02:07:52', '0');
INSERT INTO `wm_user_money` VALUES ('26', '1805', '48', '0', '1', null, '1', '购买金币', '2014-01-09 03:38:31', '0');
INSERT INTO `wm_user_money` VALUES ('27', '1805', '49', '0', '1', null, '1', '购买金币', '2014-01-08 22:33:01', '0');
INSERT INTO `wm_user_money` VALUES ('28', '1805', '50', '0', '1', null, '1', '购买金币', '2014-01-08 22:47:43', '0');
INSERT INTO `wm_user_money` VALUES ('29', '1805', '51', '0', '1', null, '1', '购买金币', '2014-01-09 10:07:16', '0');
INSERT INTO `wm_user_money` VALUES ('30', '1805', '52', '0', '1', null, '1', '购买金币', '2014-01-09 10:27:07', '0');
INSERT INTO `wm_user_money` VALUES ('31', '1805', '53', '0', '1', null, '1', '购买金币', '2014-01-09 10:28:33', '0');
INSERT INTO `wm_user_money` VALUES ('32', '1805', '54', '0', '1', null, '1', '购买金币', '2014-01-09 10:30:44', '0');
INSERT INTO `wm_user_money` VALUES ('33', '1805', '55', '0', '1', null, '1', '购买金币', '2014-01-09 10:33:00', '0');
INSERT INTO `wm_user_money` VALUES ('34', '1805', '56', '0', '1', null, '1', '购买金币', '2014-01-09 20:27:21', '0');
INSERT INTO `wm_user_money` VALUES ('35', '1805', '57', '0', '1', null, '1', '购买金币', '2014-01-09 20:45:20', '0');
INSERT INTO `wm_user_money` VALUES ('36', '1805', '58', '0', '1', null, '1', '购买金币', '2014-01-13 09:39:31', '0');
INSERT INTO `wm_user_money` VALUES ('37', '1805', '59', '0', '1', null, '1', '购买金币', '2014-01-13 09:47:45', '0');
INSERT INTO `wm_user_money` VALUES ('38', '1805', '60', '0', '1', null, '1', '购买金币', '2014-01-15 15:38:40', '0');
INSERT INTO `wm_user_money` VALUES ('39', '1270', '1', '0', '1', null, '1', '购买金币', '2014-01-15 15:47:58', '0');
INSERT INTO `wm_user_money` VALUES ('40', '1805', '61', '0', '1', null, '1', '购买金币', '2014-01-15 16:00:49', '0');
INSERT INTO `wm_user_money` VALUES ('41', '1805', '62', '0', '1', null, '1', '购买金币', '2014-01-16 10:29:40', '0');
INSERT INTO `wm_user_money` VALUES ('42', '8698', '1', '0', '1', null, '1', '购买金币', '2014-01-16 14:56:14', '0');
INSERT INTO `wm_user_money` VALUES ('43', '1805', '63', '0', '1', null, '1', '购买金币', '2014-01-23 09:38:11', '0');
INSERT INTO `wm_user_money` VALUES ('44', '1805', '64', '0', '1', null, '1', '购买金币', '2014-01-23 09:47:00', '0');
