/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:43:36
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_blog_micro_info
-- ----------------------------
DROP TABLE IF EXISTS `wm_blog_micro_info`;
CREATE TABLE `wm_blog_micro_info` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `UID` int(10) NOT NULL,
  `CONTENT` varchar(5000) DEFAULT NULL COMMENT '博客内容',
  `IMGLIST` varchar(2000) DEFAULT NULL COMMENT '图片地址',
  `PURVIEWID` tinyint(4) NOT NULL DEFAULT '0' COMMENT '发布权限(0对所有人公开，1对关注的人公开)',
  `PRAISENUMBER` int(10) NOT NULL DEFAULT '0',
  `COMMENTNUMBER` int(10) NOT NULL DEFAULT '0',
  `ISDELETE` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0未删除，1已删除',
  `VIDEOURI` varchar(1000) DEFAULT NULL COMMENT '视频地址',
  `VIDEOHOSTS` varchar(200) DEFAULT NULL,
  `VIDEOLINK` varchar(200) DEFAULT NULL,
  `VIDEOIMG` varchar(1000) DEFAULT NULL COMMENT '视频缩略图',
  `VIDEOTITLE` varchar(500) DEFAULT NULL COMMENT '视频标题',
  `BROWSENUMBER` int(10) NOT NULL DEFAULT '0' COMMENT '浏览数',
  `ADDTIME` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_blog_micro_info
-- ----------------------------
