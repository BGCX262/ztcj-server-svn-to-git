/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:43:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_blog_question
-- ----------------------------
DROP TABLE IF EXISTS `wm_blog_question`;
CREATE TABLE `wm_blog_question` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `UID` int(10) NOT NULL,
  `QUESTIONUID` int(10) NOT NULL,
  `QUESTIONCONTENT` varchar(2000) NOT NULL,
  `ANSWERCONTENT` varchar(2000) NOT NULL,
  `QUESTIONTIME` datetime NOT NULL,
  `ADDTIME` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_blog_question
-- ----------------------------
