/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:44:01
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_blog_view_comment
-- ----------------------------
DROP TABLE IF EXISTS `wm_blog_view_comment`;
CREATE TABLE `wm_blog_view_comment` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `UID` int(10) NOT NULL COMMENT '评论人ID',
  `COMMENTBLOGID` int(10) NOT NULL COMMENT '评论博客ID',
  `COMMENTCONTENT` varchar(500) NOT NULL COMMENT '评论内容',
  `COMMENTDATE` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `COMMENBLOGID` int(10) DEFAULT NULL COMMENT '回复评论ID:关联评论id',
  `ISDELETE` int(10) NOT NULL DEFAULT '0' COMMENT '是否删除:未删除(0) 删除(1)',
  `COMMENTLEVEL` int(10) NOT NULL DEFAULT '1' COMMENT '评论级数(1代表一级评论，2代表二级评论)',
  `TERMINAL` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UID` (`UID`)
) ENGINE=InnoDB AUTO_INCREMENT=1627 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_blog_view_comment
-- ----------------------------
