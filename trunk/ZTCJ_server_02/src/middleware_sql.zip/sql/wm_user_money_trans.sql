/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:47:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_user_money_trans
-- ----------------------------
DROP TABLE IF EXISTS `wm_user_money_trans`;
CREATE TABLE `wm_user_money_trans` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `UID` int(10) NOT NULL,
  `ORDERID` varchar(20) NOT NULL COMMENT '订单号',
  `MONEY` int(10) NOT NULL DEFAULT '0' COMMENT '交易金额',
  `STATUS` int(10) NOT NULL COMMENT '交易状态',
  `TRANSTYPE` varchar(10) NOT NULL COMMENT '交易类型',
  `TRANSDATE` varchar(10) NOT NULL COMMENT '交易时间',
  `ADDTIME` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_user_money_trans
-- ----------------------------
INSERT INTO `wm_user_money_trans` VALUES ('9', '1805', '0000014158172659', '1', '1001', '0001', '20140108', '2014-01-09 01:26:39');
INSERT INTO `wm_user_money_trans` VALUES ('10', '1805', '0000014158173540', '1', '1001', '0001', '20140108', '2014-01-09 01:35:18');
INSERT INTO `wm_user_money_trans` VALUES ('11', '1805', '0000014158180645', '1', '1001', '0001', '20140108', '2014-01-09 02:07:52');
INSERT INTO `wm_user_money_trans` VALUES ('12', '1805', '0000014158193806', '1', '1001', '0001', '20140108', '2014-01-09 03:38:31');
INSERT INTO `wm_user_money_trans` VALUES ('13', '1805', '0000014158223236', '1', '1001', '0001', '20140108', '2014-01-08 22:33:01');
INSERT INTO `wm_user_money_trans` VALUES ('14', '1805', '0000014158224617', '1', '1001', '0001', '20140108', '2014-01-08 22:47:43');
INSERT INTO `wm_user_money_trans` VALUES ('15', '1805', '0000014159100510', '1', '1001', '0001', '20140109', '2014-01-09 10:07:16');
INSERT INTO `wm_user_money_trans` VALUES ('16', '1805', '0000014158150318', '1', '1001', '0001', '20140108', '2014-01-09 10:27:07');
INSERT INTO `wm_user_money_trans` VALUES ('17', '1805', '0000014158150318', '1', '1001', '0001', '20140108', '2014-01-09 10:28:33');
INSERT INTO `wm_user_money_trans` VALUES ('18', '1805', '0000014158150318', '1', '1001', '0001', '20140108', '2014-01-09 10:30:44');
INSERT INTO `wm_user_money_trans` VALUES ('19', '1805', '0000014158150318', '1', '1001', '0001', '20140108', '2014-01-09 10:33:00');
INSERT INTO `wm_user_money_trans` VALUES ('20', '1805', '0000014159202737', '1', '1001', '0001', '20140109', '2014-01-09 20:27:21');
INSERT INTO `wm_user_money_trans` VALUES ('21', '1805', '0000014159204459', '1', '1001', '0001', '20140109', '2014-01-09 20:45:20');
INSERT INTO `wm_user_money_trans` VALUES ('22', '1805', '0000014153093720', '1', '1001', '0001', '20140113', '2014-01-13 09:39:31');
INSERT INTO `wm_user_money_trans` VALUES ('23', '1805', '0000014153094803', '1', '1001', '0001', '20140113', '2014-01-13 09:47:45');
INSERT INTO `wm_user_money_trans` VALUES ('24', '1805', '0000014155153156', '1', '1001', '0001', '20140115', '2014-01-15 15:38:40');
INSERT INTO `wm_user_money_trans` VALUES ('25', '1270', '0000014155154758', '1', '1001', '0001', '20140115', '2014-01-15 15:47:58');
INSERT INTO `wm_user_money_trans` VALUES ('26', '1805', '0000014155153937', '1', '1001', '0001', '20140115', '2014-01-15 16:00:49');
INSERT INTO `wm_user_money_trans` VALUES ('27', '1805', '0000014156102856', '1', '1001', '0001', '20140116', '2014-01-16 10:29:40');
INSERT INTO `wm_user_money_trans` VALUES ('28', '8698', '0000014156145534', '1', '1001', '0001', '20140116', '2014-01-16 14:56:14');
INSERT INTO `wm_user_money_trans` VALUES ('29', '1805', '0000014153093500', '1', '1001', '0001', '20140123', '2014-01-23 09:38:11');
INSERT INTO `wm_user_money_trans` VALUES ('30', '1805', '0000014153094423', '1', '1001', '0001', '20140123', '2014-01-23 09:47:00');
