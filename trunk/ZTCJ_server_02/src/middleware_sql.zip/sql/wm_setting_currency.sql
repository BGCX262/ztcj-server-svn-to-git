/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:45:33
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_setting_currency
-- ----------------------------
DROP TABLE IF EXISTS `wm_setting_currency`;
CREATE TABLE `wm_setting_currency` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PK(自动增长)',
  `CODE` varchar(50) NOT NULL COMMENT '币种代码',
  `NAME` varchar(50) NOT NULL COMMENT '币种名称',
  `MODULECODE` varchar(50) NOT NULL COMMENT '模块编号',
  `ISOPEN` int(11) NOT NULL DEFAULT '0' COMMENT '是否开放,未开放(0) 开放(1)',
  `ISTOATTENTION` tinyint(3) DEFAULT NULL COMMENT '是否推荐到想关注的币种',
  `TYPE` tinyint(3) DEFAULT NULL COMMENT '类型：1 外汇直盘，2 外汇交叉盘，3黄金',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=74 DEFAULT CHARSET=utf8 COMMENT='货币基础表';

-- ----------------------------
-- Records of wm_setting_currency
-- ----------------------------
INSERT INTO `wm_setting_currency` VALUES ('1', 'USD', '美元指数', 'USD', '1', '1', '1');
INSERT INTO `wm_setting_currency` VALUES ('2', 'USDCNY', '美元人民币', 'USDCNY', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('3', 'AUDUSD', '澳元美元', 'AUDUSD', '1', '1', '1');
INSERT INTO `wm_setting_currency` VALUES ('4', 'EURUSD', '欧元美元', 'EURUSD', '1', '1', '1');
INSERT INTO `wm_setting_currency` VALUES ('5', 'GBPUSD', '英镑美元', 'GBPUSD', '1', '1', '1');
INSERT INTO `wm_setting_currency` VALUES ('6', 'NZDUSD', '纽元美元', 'NZDUSD', '1', '1', '1');
INSERT INTO `wm_setting_currency` VALUES ('7', 'USDCAD', '美元加元', 'USDCAD', '1', '1', '1');
INSERT INTO `wm_setting_currency` VALUES ('8', 'USDCHF', '美元瑞郎', 'USDCHF', '1', '1', '1');
INSERT INTO `wm_setting_currency` VALUES ('9', 'USDHKD', '美元港元', 'USDHKD', '1', '0', '1');
INSERT INTO `wm_setting_currency` VALUES ('10', 'USDJPY', '美元日元', 'USDJPY', '1', '1', '1');
INSERT INTO `wm_setting_currency` VALUES ('11', 'USDMYR', '美元马币', 'USDMYR', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('12', 'USDSGD', '美元新元', 'USDSGD', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('13', 'USDTWD', '美元台币', 'USDTWD', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('14', 'AUDCAD', '澳元加元', 'AUDCAD', '1', '1', '2');
INSERT INTO `wm_setting_currency` VALUES ('15', 'AUDEUR', '人民币', 'AUDEUR', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('16', 'AUDHKD', '澳元港元', 'AUDHKD', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('17', 'AUDCHF', '澳元瑞郎', 'AUDCHF', '1', '0', '2');
INSERT INTO `wm_setting_currency` VALUES ('18', 'AUDGBP', '澳元英镑', 'AUDGBP', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('19', 'AUDJPY', '澳元日元', 'AUDJPY', '1', '1', '2');
INSERT INTO `wm_setting_currency` VALUES ('20', 'CADAUD', '加元澳元', 'CADAUD', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('21', 'CADEUR', '加元欧元', 'CADEUR', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('22', 'CADHKD', '加元港元', 'CADHKD', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('23', 'CADCHF', '加元瑞郎', 'CADCHF', '1', '0', '2');
INSERT INTO `wm_setting_currency` VALUES ('24', 'CADGBP', '加元英镑', 'CADGBP', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('25', 'CADJPY', '加元日元', 'CADJPY', '1', '0', '2');
INSERT INTO `wm_setting_currency` VALUES ('26', 'EURAUD', '欧元澳元', 'EURAUD', '1', '0', '2');
INSERT INTO `wm_setting_currency` VALUES ('27', 'EURCAD', '欧元加元', 'EURCAD', '1', '0', '2');
INSERT INTO `wm_setting_currency` VALUES ('28', 'EURHKD', '欧元港元', 'EURHKD', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('29', 'EURCHF', '欧元瑞郎', 'EURCHF', '1', '1', '2');
INSERT INTO `wm_setting_currency` VALUES ('30', 'EURGBP', '欧元英镑', 'EURGBP', '1', '1', '2');
INSERT INTO `wm_setting_currency` VALUES ('31', 'EURJPY', '欧元日元', 'EURJPY', '1', '1', '2');
INSERT INTO `wm_setting_currency` VALUES ('32', 'HKDAUD', '港元澳元', 'HKDAUD', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('33', 'HKDCAD', '港元加元', 'HKDCAD', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('34', 'HKDEUR', '港元欧元', 'HKDEUR', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('35', 'HKDCHF', '港元瑞郎', 'HKDCHF', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('36', 'HKDGBP', '港元英镑', 'HKDGBP', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('37', 'HKDJPY', '港元加元', 'HKDJPY', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('38', 'CHFAUD', '瑞郎澳元', 'CHFAUD', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('39', 'CHFCAD', '瑞郎加元', 'CHFCAD', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('40', 'CHFEUR', '瑞郎欧元', 'CHFEUR', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('41', 'CHFHKD', '瑞郎港元', 'CHFHKD', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('42', 'CHFGBP', '瑞郎英镑', 'CHFGBP', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('43', 'CHFJPY', '瑞郎日元', 'CHFJPY', '1', '0', '2');
INSERT INTO `wm_setting_currency` VALUES ('44', 'GBPAUD', '英镑澳元', 'GBPAUD', '1', '0', '2');
INSERT INTO `wm_setting_currency` VALUES ('45', 'GBPCAD', '英镑加元', 'GBPCAD', '1', '0', '2');
INSERT INTO `wm_setting_currency` VALUES ('46', 'GBPEUR', '英镑欧元', 'GBPEUR', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('47', 'GBPCHF', '英镑瑞郎', 'GBPCHF', '1', '1', '2');
INSERT INTO `wm_setting_currency` VALUES ('48', 'GBPHKD', '英镑港元', 'GBPHKD', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('49', 'GBPJPY', '英镑日元', 'GBPJPY', '1', '1', '2');
INSERT INTO `wm_setting_currency` VALUES ('50', 'USDMOP', '美元澳门元', 'USDMOP', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('51', 'AUDNZD', '澳元纽元', 'AUDNZD', '1', '0', '2');
INSERT INTO `wm_setting_currency` VALUES ('52', 'EURNZD', '欧元纽元', 'EURNZD', '1', '0', '2');
INSERT INTO `wm_setting_currency` VALUES ('53', 'GBPNZD', '英镑纽元', 'GBPNZD', '1', '0', '2');
INSERT INTO `wm_setting_currency` VALUES ('54', 'GBPCNY', '英镑人民币', 'GBPCNY', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('55', 'CNYJPY', '人民币日元', 'CNYJPY', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('56', 'EURCNY', '欧元人民币', 'EURCNY', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('57', 'CHFCNY', '瑞郎人民币', 'CHFCNY', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('58', 'SGDCNY', '新元人民币', 'SGDCNY', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('59', 'CADCNY', '加元人民币', 'CADCNY', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('60', 'HKDCNY', '港元人民币', 'HKDCNY', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('61', 'AUDCNY', '澳元人民币', 'AUDCNY', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('62', 'NZDCNY', '纽元人民币', 'NZDCNY', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('63', 'CADNZD', '加元纽元', 'CADNZD', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('64', 'TWDCNY', '台币人民币', 'TWDCNY', '1', '0', null);
INSERT INTO `wm_setting_currency` VALUES ('65', 'XAU', '现货黄金', 'XAU', '1', '1', '3');
INSERT INTO `wm_setting_currency` VALUES ('66', 'XAG', '现货白银', 'XAG', '1', '1', '3');
INSERT INTO `wm_setting_currency` VALUES ('67', 'Au(T+D)', 'TD黄金', 'Au(T+D)', '1', '1', null);
INSERT INTO `wm_setting_currency` VALUES ('68', 'Ag(T+D)', 'TD白银', 'Ag(T+D)', '1', '1', null);
INSERT INTO `wm_setting_currency` VALUES ('69', 'Au99.99', '99金', 'Au99.99', '1', '1', null);
INSERT INTO `wm_setting_currency` VALUES ('70', 'Ag99.99', '99银', 'Ag99.99', '1', '1', null);
INSERT INTO `wm_setting_currency` VALUES ('73', 'NZDJPY', '纽元日元', 'NZDJPY', '1', '1', '2');
