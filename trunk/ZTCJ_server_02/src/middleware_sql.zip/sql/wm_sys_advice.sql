/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:45:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_sys_advice
-- ----------------------------
DROP TABLE IF EXISTS `wm_sys_advice`;
CREATE TABLE `wm_sys_advice` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `CONTENT` varchar(200) NOT NULL,
  `ADDTIME` datetime NOT NULL,
  `ADDADMINID` int(10) NOT NULL,
  `ADMINIP` varchar(20) NOT NULL,
  `DELETESTATE` int(10) NOT NULL DEFAULT '0' COMMENT '删除状态：1已删除 0未删除',
  `ADMINREMARK` varchar(200) DEFAULT NULL COMMENT '备注说明',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_sys_advice
-- ----------------------------
