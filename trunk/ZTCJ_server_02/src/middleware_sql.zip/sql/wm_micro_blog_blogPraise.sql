/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:45:00
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_micro_blog_blogPraise
-- ----------------------------
DROP TABLE IF EXISTS `wm_micro_blog_blogPraise`;
CREATE TABLE `wm_micro_blog_blogPraise` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PK(自动增长)',
  `UID` int(11) NOT NULL COMMENT '会员编号',
  `BLOGID` int(11) DEFAULT NULL COMMENT '博客编号',
  `TYPE` int(10) NOT NULL DEFAULT '0' COMMENT '赞贬类型,赞(0) 取消赞(1)',
  `ADDTIME` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `ADDIP` varchar(50) NOT NULL COMMENT '操作IP',
  `COMMENTID` int(11) DEFAULT NULL COMMENT '评论ID',
  PRIMARY KEY (`ID`),
  KEY `UID` (`UID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=965 DEFAULT CHARSET=utf8 COMMENT='博客赞列表';

-- ----------------------------
-- Records of wm_micro_blog_blogPraise
-- ----------------------------
