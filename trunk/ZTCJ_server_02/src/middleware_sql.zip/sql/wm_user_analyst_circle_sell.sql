/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:46:12
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_user_analyst_circle_sell
-- ----------------------------
DROP TABLE IF EXISTS `wm_user_analyst_circle_sell`;
CREATE TABLE `wm_user_analyst_circle_sell` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `UID` int(10) NOT NULL COMMENT '用户id',
  `ANAID` int(10) NOT NULL COMMENT '分析师id',
  `CID` int(10) NOT NULL COMMENT '策略id',
  `ADDTIME` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `ADDIP` varchar(50) NOT NULL COMMENT '添加ip',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_user_analyst_circle_sell
-- ----------------------------
