/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:42:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_blog_classRole
-- ----------------------------
DROP TABLE IF EXISTS `wm_blog_classRole`;
CREATE TABLE `wm_blog_classRole` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `CLASSID` int(10) NOT NULL COMMENT '博客分类ID',
  `ROLE` varchar(5) NOT NULL COMMENT '角色',
  `NEWROLE` int(10) DEFAULT NULL COMMENT '角色，将来替换ROLE',
  `ROLETAG` int(5) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wm_blog_classRole
-- ----------------------------
INSERT INTO `wm_blog_classRole` VALUES ('1', '1', 'N', '2', '2');
INSERT INTO `wm_blog_classRole` VALUES ('2', '1', 'F', '3', '3');
INSERT INTO `wm_blog_classRole` VALUES ('3', '1', 'D', '4', '4');
INSERT INTO `wm_blog_classRole` VALUES ('4', '1', 'A', '1', '1');
INSERT INTO `wm_blog_classRole` VALUES ('5', '2', 'A', '1', '1');
INSERT INTO `wm_blog_classRole` VALUES ('6', '2', 'D', '4', '4');
INSERT INTO `wm_blog_classRole` VALUES ('7', '2', 'F', '3', '3');
INSERT INTO `wm_blog_classRole` VALUES ('8', '2', 'N', '2', '2');
INSERT INTO `wm_blog_classRole` VALUES ('9', '3', 'A', '1', '1');
INSERT INTO `wm_blog_classRole` VALUES ('10', '3', 'F', '3', '3');
INSERT INTO `wm_blog_classRole` VALUES ('11', '3', 'D', '4', '4');
INSERT INTO `wm_blog_classRole` VALUES ('12', '3', 'N', '2', '2');
INSERT INTO `wm_blog_classRole` VALUES ('13', '4', 'A', '1', '1');
INSERT INTO `wm_blog_classRole` VALUES ('14', '4', 'F', '3', '3');
INSERT INTO `wm_blog_classRole` VALUES ('15', '4', 'D', '4', '4');
INSERT INTO `wm_blog_classRole` VALUES ('16', '4', 'N', '2', '2');
INSERT INTO `wm_blog_classRole` VALUES ('17', '5', 'A', '1', '1');
INSERT INTO `wm_blog_classRole` VALUES ('18', '5', 'F', '3', '3');
INSERT INTO `wm_blog_classRole` VALUES ('19', '5', 'D', '4', '4');
INSERT INTO `wm_blog_classRole` VALUES ('20', '5', 'N', '2', '2');
INSERT INTO `wm_blog_classRole` VALUES ('21', '6', 'D', '4', '4');
INSERT INTO `wm_blog_classRole` VALUES ('22', '6', 'A', '1', '1');
INSERT INTO `wm_blog_classRole` VALUES ('23', '7', 'A', '1', '1');
INSERT INTO `wm_blog_classRole` VALUES ('24', '7', 'F', '3', '3');
INSERT INTO `wm_blog_classRole` VALUES ('25', '2', 'N', '2', '2');
INSERT INTO `wm_blog_classRole` VALUES ('27', '9', 'A', '1', '1');
INSERT INTO `wm_blog_classRole` VALUES ('28', '9', 'D', '4', '4');
INSERT INTO `wm_blog_classRole` VALUES ('29', '9', 'F', '3', '3');
INSERT INTO `wm_blog_classRole` VALUES ('30', '9', 'N', '2', '2');
INSERT INTO `wm_blog_classRole` VALUES ('31', '10', 'A', '1', '1');
INSERT INTO `wm_blog_classRole` VALUES ('32', '10', 'D', '4', '4');
INSERT INTO `wm_blog_classRole` VALUES ('33', '10', 'F', '3', '3');
INSERT INTO `wm_blog_classRole` VALUES ('34', '10', 'N', '2', '2');
INSERT INTO `wm_blog_classRole` VALUES ('35', '1', 'A', '5', '5');
INSERT INTO `wm_blog_classRole` VALUES ('36', '2', 'A', '5', '5');
INSERT INTO `wm_blog_classRole` VALUES ('37', '3', 'A', '5', '5');
INSERT INTO `wm_blog_classRole` VALUES ('38', '4', 'A', '5', '5');
INSERT INTO `wm_blog_classRole` VALUES ('39', '5', 'A', '5', '5');
INSERT INTO `wm_blog_classRole` VALUES ('40', '7', 'A', '5', '5');
INSERT INTO `wm_blog_classRole` VALUES ('41', '8', 'A', '5', '5');
INSERT INTO `wm_blog_classRole` VALUES ('42', '9', 'A', '5', '5');
INSERT INTO `wm_blog_classRole` VALUES ('43', '10', 'A', '5', '5');
INSERT INTO `wm_blog_classRole` VALUES ('44', '1', 'A', '6', '6');
INSERT INTO `wm_blog_classRole` VALUES ('45', '2', 'A', '6', '6');
INSERT INTO `wm_blog_classRole` VALUES ('46', '3', 'A', '6', '6');
INSERT INTO `wm_blog_classRole` VALUES ('47', '4', 'A', '6', '6');
INSERT INTO `wm_blog_classRole` VALUES ('48', '5', 'A', '6', '6');
INSERT INTO `wm_blog_classRole` VALUES ('49', '6', 'A', '6', '6');
INSERT INTO `wm_blog_classRole` VALUES ('50', '9', 'A', '6', '6');
INSERT INTO `wm_blog_classRole` VALUES ('51', '10', 'A', '6', '6');
