/*
Navicat MySQL Data Transfer

Source Server         : 254
Source Server Version : 50612
Source Host           : 192.168.0.254:3306
Source Database       : wm_ztcj

Target Server Type    : MYSQL
Target Server Version : 50612
File Encoding         : 65001

Date: 2014-04-15 14:47:34
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wm_user_interest
-- ----------------------------
DROP TABLE IF EXISTS `wm_user_interest`;
CREATE TABLE `wm_user_interest` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'PK(自动增长)',
  `UID` int(11) NOT NULL COMMENT '关联用户ID',
  `INTERESTNAME` varchar(50) NOT NULL COMMENT '兴趣名称',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员信息：个人兴趣\r\n';

-- ----------------------------
-- Records of wm_user_interest
-- ----------------------------
